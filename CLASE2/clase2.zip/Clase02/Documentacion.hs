module Documentacion
where
    {- este modulo muestra como documentar y comentar
    este comentario multilinea se ignora -}
    --este comentario tambien se ignora
    
    -- |Documentacion de id
    -- id es la identidad
    id x = x
    
    {- |Documentacion multilinea
  constante5 es la funcion constante 5-}
    constante5 = 5    
