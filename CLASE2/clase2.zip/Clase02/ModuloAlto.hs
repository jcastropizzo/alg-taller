module ModuloAlto
where
    import ModuloMedio
    import ModuloBase2
    
    pepe = maximoAbsoluto 1 2
    quique = absoluto 1
    --pancho = maximo 1 2
